#
#
#
# jt. Mayo 2013. Lista de Records de Ahorcado
#
#
lin=`wc -l jugadores.records | cut -f1 -d" "`
longitud=0
sort -nr jugadores.records > xy
cat -n xy > posicion
rm xy
echo " " > lista
echo "RECORDS DEL AHORCADO" >> lista
echo "--------------------" >> lista
echo " " >> lista
echo "PUESTO --- RECORD --- NOMBRE" >> lista
echo "----------------------------" >> lista

for (( i=1 ; i<=9; i++ ));do
# record=`grep "     $i" posicion | cut --delimiter=";" -f1 | cut -c8-25`
  
    record=`grep "     $i" posicion | cut --delimiter=";" -f1 | cut -c8-25`
    nombre=`grep "     $i" posicion | cut --delimiter=";" -f2 | cut -c1-7`
 	  long=${#record}

  case $long in
    5)
     record="$record";;
    4)
     record=" $record";;
    3)
     record="  $record";;
    2)
     record="   $record";;
    1)
     record="    $record";;
   esac

  echo "     $i ---  $record --- $nombre"  >> lista

done
echo " " >> lista

rm posicion



