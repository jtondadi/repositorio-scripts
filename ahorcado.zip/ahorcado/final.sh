i=12
col=40
reverse=40
fila=12 
for (( i=12; i>2; i-- ));do
 col=`expr $col - 1`
 reverse=`expr $reverse + 1`
 fila=`expr $fila + 1`
 tput cup $i $col
 echo "*"
 tput cup $i $reverse
 echo "*"
 tput cup $fila $col
 echo "*"
 tput cup $fila $reverse
 echo "*"
done
tput cup 80 1
echo " "

