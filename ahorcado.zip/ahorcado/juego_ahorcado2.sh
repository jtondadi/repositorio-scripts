
#
# version_9/5/2013 07:00h.
# modificaciones posteriores
# 14-05-13 6:30h.
# ahorcado
# jt. Abril/Mayo 2013
#
#
#
# comprobando MAXIMA PUNTUACION OBTENIDA y PUNTOS TOTALES POR PALABRAS
# el fichero jugadores.records es el utilzado para ordenar, y comprobar puntuaciones
#
clear
sort -nr jugadores.records > xy
cat -n xy > yo
record_total=`grep "     1" yo | cut --delimiter=";" -f1 | cut -c8-25`
nombre_total=`grep "     1" yo | cut --delimiter=";" -f2 | cut -c1-8`
rm yo
rm xy
cat lista
echo "Pulsa una tecla para continuar ..."
read pausa

# dibujo del AHORCADO (funciones dibujo_0 a dibujo_5) - para sacar en pantalla con printf
dibujo_0()
{
 tput cup 1 1
 printf "                     
========================
                        *
         EL            **
        JUEGO           *
         DEL           **
       AHORCADO         *
                       **
    by Jtd(mayo 2.013)  *
                       **
                        *
  SHELL SCRIPT         **
 --------------------------"
}

dibujo_1()
{
 tput cup 1 1
 printf "
      *******************
                       **
                       **
                       **
                       **
                       **
                       **
                       **
                       **
                       **
                       **
                       **
                       **
 ######################**
 --------------------------"
}

dibujo_2()
{
 tput cup 1 1
 printf "
      *******************
             *         **
             *         **
                       **
                       **
                       **
                       **
                       **
                       **
                       **
                       **
                       **
                       **
 ######################**
 --------------------------"
}

dibujo_3()
{
 tput cup 1 1
 printf "
      *******************
             *         **
             *         **
            ***        **
           *x x*       **
           * x *       **
            ***        **
             *         **
             *         **
             *         **
                       **
                       **
                       **
 ######################**
 --------------------------"
}

dibujo_4()
{
 tput cup 1 1
 printf "
      *******************
             *         **
             *         **
            ***        **
           *x x*       **
           * x *       **
            ***        **
             *         **
        *    *    *    **
         * * * * *     **
                       **
                       **
                       **
 ######################**
 --------------------------"
}

dibujo_5()
{
 tput cup 1 1
 printf "
      *******************
             *         **
             *         **
            ***        **
           *x x*       **
           * x *       **
            ***        **
             *         **
        *    *    *    **
         * * * * *     **
             *         **
            * *        **
           *   *       **
 ######################**
 --------------------------"
}

#
# localizar letra introducida dentro de la cadena (PALABRA) a adivinar
# con la función_ encontrar_letra()
#

encontrar_letra()
{
i=0
col=26
t=0

for ((  i = 1;  i <= len_palabra_adivinar;  i++ )); do
 x=`expr substr $palabra $i 1`
 col=`expr $col + 1`
 
  if [ "$letra" == "$x" ]; then
     tput cup 6 $col
     echo -n $x
     temp=1
     t=1
     cadena=`echo $cadena$x`
    else
     temp=0
  fi
done

 if [ $t -eq 1 ]; then
   temp=1
  else
   temp=0
 fi
}

# inicio del programa

# palabras -> la variable toma el valor de las palabras almacenadas en el archivo
# total_palabras -> la variable toma el total de las palabras contenidas en el archivo (cuenta líneas)
# .. deshabilitado por el momento ..
#


acertadas=" "
contador_palabras=0
aciertos=0
palabra_acertada=" "
puntuacion_total=0
jugar="s"

clear
for (( i=0; i<=5; i++ ));do
 dibujo_$i
done

tput cup 6 30
echo -n "Dime tu nombre ? "
read jugador

nombre=`grep ";$jugador" jugadores.records | cut --delimiter=';' -f2`
record=`grep ";$jugador" jugadores.records | cut --delimiter=';' -f1`

  if [ "$jugador" = "$nombre" ]; then
     tput cup 11 30     
     echo -n "Actualmente tienes $record puntos. "
     tput cup 12 30
     echo -n "Pulsa una tecla para continuar ..."
     read pausa
     tput cup 11 30
     echo "                                                    "
     tput cup 12 30
     echo "                                                    "
  fi

#
# Vamos pasando a la variable "palabra" el valor de palabras (contenido del archivo)
#
# random%3 -> son 3 valores, iniciandosé en 0.#
# con ramdom%3 selecciona el archivo de palabras aleatoriamente
#

opcion=0
 while [ $opcion = 0 ]; do

        tput cup 3 30
        echo "TIPO DE JUEGO"
 	tput cup 6 30
	echo "1. ELEGIR ARCHIVO DE PALABRAS"
	tput cup 7 30
	echo "2. ALEATORIO"
	tput cup 9 30
	echo -n "Selecciona opcion: "
	read opcion

	case $opcion in
 	1)
	 total_archivos=`ls -l palabras? | wc -l | cut -c1-2`
	 total_archivos=`expr $total_archivos - 1`
         tput cup 9 30
	 echo -n "Archivo: (0 a $total_archivos) _ " 
	 read archivo
         break;;
        2)
	  archivo=`echo $((RANDOM%3))`
          break;;
	 *)
  opcion=0;;
	esac
 done

# tipo de juego
case $archivo in
	 0) 
           total_palabras=`wc -l palabras0 | cut -f1 -d" "`
           palabras=`cat palabras0`
           archivo_juego="variedad";;
	 1)
           total_palabras=`wc -l palabras1 | cut -f1 -d" "`
           palabras=`cat palabras1`
           archivo_juego="informatica";;
	 2)
           total_palabras=`wc -l palabras2 | cut -f1 -d" "`
           palabras=`cat palabras2`
           archivo_juego="cocina";;
   *)
    palabras=`cat palabras0 palabras1 palabras2 > palabras3` 
    tipo_orden=`echo $((RANDOM%2))`
    if [ $tipo_orden -eq 0 ]; then
      sort palabras3 > palabras4
     elif [ $tipo_orden -eq 1 ]; then
      sort -r palabras3 > palabras4
    fi
     palabras=`cat palabras4`
     total_palabras=`wc -l palabras4 | cut -f1 -d" "`
	for (( x=1 ; x<=$total_palabras ; x++ )); do
 	  elegir=`echo $((RANDOM%total_palabras))`
          elegir=`expr $elegir + 1`
	  palabra=`sed -n ''$elegir'p' palabras4`
	  echo $palabra >> palabras5
        done
     palabras=`cat palabras5`
     archivo_juego="mezcla$tipo_orden"
     rm palabras3
     rm palabras4
     rm palabras5
   fdsddd;;

esac
  
   total=`expr $total_palabras \* 500`

for palabra in $palabras 
  do

	clear
	puntuacion=500
	jugar="s"
	letras=" "
	introduce=1
	contador_palabras=`expr $contador_palabras + 1`
	tput cup 2 26
	echo "$jugador, Juego ** $archivo_juego ** con _ $total_palabras _ palabras."
	tput cup 21 2
	echo "En esta partida llevas: $puntuacion_total puntos."
	tput cup 22 2
	echo "Tu puntuacion maxima: $record puntos."
        tput cup 23 2
        echo "RECORD ACTUAL: $record_total por $nombre_total."
  

        # presentación del juego (función dibujo_0)
	dibujo_0
	len_palabra_adivinar=`expr length $palabra`
	contar=0
	suma=0
	i=26	
	cadena=" "
	guardar="1"
	letra=" "
	len_guardar=0
	columna=26
	intentos=0
	y=" "


# colocar el número de letras
  tput cup 4 26
  echo " Adivinando palabra nº: $contador_palabras de $total_palabras."
	 while [ $contar -lt $len_palabra_adivinar ]; do
	  i=`expr $i + 1`
	  tput cup 6 $i
	  echo "*"
	  contar=`expr $contar + 1`	
	 done

	 while [ "$jugar" = "s" ]; do

         columna=`expr $columna + 1`
         introduce=1
 	 temp=1
 	 longitud_letra=1
 	 guardar=`echo $guardar$letra`
 	 letra=" "


#
# COMPROBAR LETRAS INTRODUCIDAS
# pasar una letra al historial para comprobar que está bien
# 

   while [ -z $letra ]; do
	    tput cup 17 2
	    echo -n "Dime una letra:"
	    read letra
	    tput cup 17 2
	    echo -n "                                "
	   done

#
# comprobar que lo introducido no está ya acumulado
#
#

    longitud_letra=${#letra}
    if [ $longitud_letra -eq 1 ]; then
      len_guardar=${#guardar}
      tput cup 8 26 
     else
      letra=`expr substr $letra 1 1`
    fi

     for (( i = 0 ; i <= len_guardar; i++ )); do
      y=`expr substr $guardar $i 1`
      tput cup 9 26
       if test "$letra" == "$y"
        then
         introduce=0
         temp=1
         guardando=1
         letra=""
        fi
     done

# HISTORIAL DE LETRAS INTRODUCIDAS

    letras=$letras$letra
    tput cup 18 2
    echo "Historial de letras:"
    tput cup 19 2
    echo $letras

# 
# AHORCADO 
# Verificar la letra introducida, y dibujar el ahorcado, sino es correcta.
# sacara funcion (dibujo_1 a dibujo_5) según se vaya fallado.d
# VERIFICA LETRA CUANDO LA VARIABLE INTRODUCE TIENE VALOR 1 (dijeramos no se ha repetido la letra)
# 
  
  if [ $introduce -eq 1 ]; then
    encontrar_letra
  fi

  if [ $temp -eq 0 ]; then
    intentos=`expr $intentos + 1`
    puntuacion=`expr $puntuacion - 100`
     case $intentos in 
      1)
       dibujo_1;;
      2)
       dibujo_2;;
      3)
       dibujo_3;;
      4)
       dibujo_4;;
      5)
       dibujo_5;;
     esac
   fi

    tput cup 8 27
    echo "Puntos a obtener: $puntuacion"

  #
  #
  # COMPROBAR la longitud de la cadena que se está adivinando con
  # la cadenta total de la palabra a adivinar, y si es correcta
  # hemos acertado la palabra.
  #
  #

	 longitud_cadena=${#cadena}
	 len_palabra_adivinar=`expr length $palabra`

		 tput cup 8 26
		 if [ $longitud_cadena -eq $len_palabra_adivinar ]; then
		   echo "Te llevas: $puntuacion puntos."
		   acierto=1
		   aciertos=`expr $aciertos + 1`
		   jugar="no"
		   puntuacion_total=`expr $puntuacion_total + $puntuacion`
		  elif [ $intentos -eq 5 ]; then
		   echo " No adivinaste '$palabra'."
		   acierto=0
		   jugar="no"
		 fi

	 done

  # 
  # QUEREMOS SEGUIR JUGANDO
  # break 2 {salta 2 bucle FOR palabras
  # break 1 {salta 1 bucle WHILE jugar
  #
 
  juego=" "
  total=`expr $total - $puntuacion`
  while [ "$juego" <> "s" ]; do
 	 tput cup 11 26
   echo -n " ¿Continuar jugando (s/n)? "
	  read juego
   if [ "$juego" = "n" ]; then
    break 2
   elif [ -z $juego ]; then 
    juego=" "
   elif [ "$juego" = "s" ]; then
    break 1
   fi
  done
 done

clear
tput cup 22 2
echo "Aciertos: $aciertos de $contador_palabras. Anotas: $puntuacion_total puntos."
nombre=`grep ";$jugador" jugadores.records | cut --delimiter=';' -f2`
record=`grep ";$jugador" jugadores.records | cut --delimiter=';' -f1`


  if [ "$jugador" = "$nombre" ]; then
   if [ $puntuacion_total -gt $record ] ; then
     tput cup 25 2
     echo "NUEVO RECORD !!  $puntuacion_total puntos."
     sed "s/$record;$jugador/$puntuacion_total;$jugador/" jugadores.records > x
     rm jugadores.records
     mv x jugadores.records
    else
     tput cup 25 2
     echo "No has superado tu limite de $record puntos."
   fi

  else
	 echo "$puntuacion_total;$jugador;$aciertos;$contador_palabras;$archivo" >> jugadores.records
  fi
  
./listarecords.sh
tput cup 26 2
cat lista
#rm lista
rm s

